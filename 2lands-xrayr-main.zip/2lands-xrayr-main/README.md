# 2lands-xrayr

XrayR nhưng cài nhanh hơn bình thường

# Cách cài đặt

```
bash <(curl -Ls https://raw.githubusercontent.com/2landsme/2lands-xrayr/master/xrayr2lands.sh)
```
